# Read in the data from the CSV file
data1 <- read.csv("C:/Users/uc201/OneDrive/Ambiente de Trabalho/mei-assignment/code/results/Dinic.csv", stringsAsFactors = FALSE)
data2 <- read.csv("C:/Users/uc201/OneDrive/Ambiente de Trabalho/mei-assignment/code/results/EK.csv", stringsAsFactors = FALSE)
data3 <- read.csv("C:/Users/uc201/OneDrive/Ambiente de Trabalho/mei-assignment/code/results/MPM.csv", stringsAsFactors = FALSE)

# Extract the time data for each algorithm
data1$time <- as.numeric(data1$time)
data2$time <- as.numeric(data2$time)
data3$time <- as.numeric(data3$time)


ek_times <- data2["time"]
dinic_times <- data1["time"]
mpm_times <- data3["time"]

length(ek_times)
length(dinic_times)
length(mpm_times)

print(ek_times)

t.test(ek_times, dinic_times)

# Perform the Mann-Whitney test for each pair of algorithms
result1 <- wilcox.test(ek_times, dinic_times)
result2 <- wilcox.test(ek_times, mpm_times)

#3rd hypothis
result3 <- wilcox.test(dinic_times, mpm_times)

# Print the results
print(result1)
print(result2)
print(result3)