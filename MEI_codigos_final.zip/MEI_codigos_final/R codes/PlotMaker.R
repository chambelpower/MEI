# Read in the data from the csv file
data <- read.csv("C:/Users/uc201/OneDrive/Ambiente de Trabalho/mei-assignment/code/results/MPM_r_changing.csv", header=TRUE)


# Convert the time column to numeric
data$time <- as.numeric(data$time)

# Load the ggplot2 library
library(ggplot2)

# Create the scatterplot
ggplot(data, aes(x=r, y=time)) +
  geom_point() +
  xlab("r") +
  ylab("time")