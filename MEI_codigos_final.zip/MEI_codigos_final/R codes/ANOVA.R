# Load necessary libraries
library(tidyverse)

# Read in data
data <- read.csv("C:/Users/uc201/OneDrive/Ambiente de Trabalho/mei-assignment/code/results/geral.csv")

# Check assumptions of ANOVA test
#plot(time ~ algorithm, data) # check for homogeneity of variances
shapiro.test(data$time) # check for normality of residuals

# Perform one-way ANOVA
aov_results <- aov(time ~ algorithm, data)

# View results
summary(aov_results)