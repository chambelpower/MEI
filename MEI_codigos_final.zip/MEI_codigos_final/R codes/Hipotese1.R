# Load necessary libraries
library(tidyverse)

# Read in data
data1 <- read.csv("C:/Users/uc201/OneDrive/Ambiente de Trabalho/mei-assignment/code/results/MPM_r.csv")
data2 <- read.csv("C:/Users/uc201/OneDrive/Ambiente de Trabalho/mei-assignment/code/results/Dinic_r.csv")
data3 <- read.csv("C:/Users/uc201/OneDrive/Ambiente de Trabalho/mei-assignment/code/results/EK_r.csv")

# Select the columns for maximum capacity and computing time for each algorithm
mpm <- data1 %>% select(n, time) %>% rename(max_capacity = n, computing_time = time)
dinic <- data2 %>% select(n, time) %>% rename(max_capacity = n, computing_time = time)
ek <- data3 %>% select(n, time) %>% rename(max_capacity = n, computing_time = time)

# Perform linear regression analysis for each algorithm
fit_mpm <- lm(computing_time ~ max_capacity, data = mpm)
fit_dinic <- lm(computing_time ~ max_capacity, data = dinic)
fit_ek <- lm(computing_time ~ max_capacity, data = ek)

# Extract the slope and p-value for each model
slope_mpm <- coef(fit_mpm)["max_capacity"]
p_value_mpm <- summary(fit_mpm)$coefficients[2,4]
slope_dinic <- coef(fit_dinic)["max_capacity"]
p_value_dinic <- summary(fit_dinic)$coefficients[2,4]
slope_ek <- coef(fit_ek)["max_capacity"]
p_value_ek <- summary(fit_ek)$coefficients[2,4]

# Print the results
print(paste("MPM: slope =", slope_mpm, ", p-value =", p_value_mpm))
print(paste("Dinic: slope =", slope_dinic, ", p-value =", p_value_dinic))
print(paste("EK: slope =", slope_ek, ", p-value =", p_value_ek))

# If the p-value is less than 0.05, the slope is significantly different from zero
# and there is a statistically significant relationship between the maximum capacity of an arc
# and the computing time for that algorithm.