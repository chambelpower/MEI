# Load required libraries
library(ggplot2)
library(scales)
library(RColorBrewer)
data <- read.csv("C:/Users/uc201/OneDrive/Ambiente de Trabalho/mei-assignment/code/results/geral.csv")

# Set custom color palette
palette <- brewer.pal(3, "Set2")

# Visualize results using a line plot with points and error bars
ggplot(data, aes(x = algorithm, y = time, color = algorithm)) +
  geom_line() +
  geom_point(size = 4) +
  geom_errorbar(aes(ymin = time, ymax = time ), width = 0.2) +
  scale_y_continuous(labels = comma) +
  labs(title = "Comparison of Algorithm Running Times",
       x = "Algorithm",
       y = "Running Time (seconds)") +
  theme_bw() +
  theme(plot.title = element_text(face = "bold", size = 14),
        axis.title = element_text(face = "bold", size = 12),
        axis.text = element_text(size = 10)) +
  scale_color_manual(values = palette)

