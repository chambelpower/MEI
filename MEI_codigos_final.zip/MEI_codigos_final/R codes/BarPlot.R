# Load necessary libraries
library(tidyverse)
library(ggplot2)
library(scales)
library(RColorBrewer)
# Read in data
data <- read.csv("C:/Users/uc201/OneDrive/Ambiente de Trabalho/mei-assignment/code/results/geral_r.csv")

# Perform Kruskal-Wallis test
#kw_results <- kruskal.test(time ~ algorithm, data)

# View results
#summary(kw_results)

# Visualize results using a box plot
#ggplot(data, aes(x = algorithm, y = time)) +
#geom_boxplot()

# Load required libraries

# Load required libraries


# Set custom color palette
palette <- brewer.pal(2, "Set2")

# Visualize results using a bar plot
ggplot(data, aes(x = algorithm, y = time, fill = algorithm)) +
  geom_bar(stat = "identity", width = 0.5) +
  scale_y_continuous(labels = comma) +
  labs(title = "Comparison of Computing Times for Dinic and MPM",
       x = "Algorithm",
       y = "Computing Time (seconds)") +
  theme_bw() +
  theme(plot.title = element_text(face = "bold", size = 14),
        axis.title = element_text(face = "bold", size = 12),
        axis.text = element_text(size = 10)) +
  scale_fill_manual(values = palette)