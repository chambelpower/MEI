data3= read.csv("C:/Users/diver/Downloads/mei-assignment/code/results/MPM.csv")

arcsq<-data3$n^3

data3$p <-((data3$n * (data3$n - 1))/2) * data3$p

pairs(data3)
lm <- lm(data3$time ~ arcsq)
print(lm)
print(summary(lm))

plot( arcsq,data3$time,xlab="(N^3)",ylab = "CPU time")
abline(lm)

m <- lm(data3$result ~ data3$n)
print(m)
print(summary(m))
plot( data3$n,data3$result,xlab = "r",ylab="Result")
abline(m)