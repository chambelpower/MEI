data3= read.csv("C:/Users/diver/Downloads/mei-assignment/code/results/Dinic.csv")

data3$p <-((data3$n * (data3$n - 1))/2) * data3$p

pairs(data3)

 

nsq<-data3$n^2
t<-data3$p*nsq

lm <- lm(data3$time ~ t)
print(lm)
print(summary(lm))

plot(t,data3$time,xlab="A x (N^2)",ylab = "CPU time")
abline(lm)
