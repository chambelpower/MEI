data3= read.csv("C:/Users/diver/Downloads/mei-assignment/code/results/EK.csv")

data3$p <-((data3$n * (data3$n - 1))/2) * data3$p

arcsq<-data3$p^2
t<-arcsq*data3$n


pairs(data3)

lm <- lm(data3$time ~ t)
print(lm)
print(summary(lm))

plot(t,data3$time,xlab="N x (A^2)",ylab = "CPU time")
abline(lm)
