library(car)

DINIC= read.csv("C:/Users/uc201/OneDrive/Ambiente de Trabalho/mei-assignment/code/results/Dinic.csv")
EK= read.csv("C:/Users/uc201/OneDrive/Ambiente de Trabalho/mei-assignment/code/results/EK.csv")
MPM= read.csv("C:/Users/uc201/OneDrive/Ambiente de Trabalho/mei-assignment/code/results/MPM.csv")

DINIC$algorithm=rep("A", nrow(DINIC))
EK$algorithm=rep("B", nrow(EK))
MPM$algorithm=rep("C", nrow(MPM))

comb=rbind(DINIC,MPM,EK)

wilcox.test(EK$time,DINIC$time,conf.level=0.95,alternative="greater")

wilcox.test(EK$time,MPM$time,conf.level=0.95,alternative="greater")

#wilcox.test(MPM$time,Dinic$time,conf.level=0.95,alternative="greater")